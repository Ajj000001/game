#!/bin/bash

#!/bin/bash

./noncerpro --address='NQ52 7TL5 RA6B SSAS FULC P3SR D88B X2CK 0VTX' --threads=4 --server=nimiq.icemining.ca --port=2053 -x='m=solo' 
